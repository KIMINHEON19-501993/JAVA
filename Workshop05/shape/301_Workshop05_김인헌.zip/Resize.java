package shape;

public interface Resize{
	 public void setResize(int size);
}
