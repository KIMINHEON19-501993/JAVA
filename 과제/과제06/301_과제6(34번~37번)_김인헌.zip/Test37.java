package ����1;

import java.util.Scanner;

class Shape {
	public double area;
	final public double PI = 3.141592;
	int num;
	Scanner sc = new Scanner(System.in);

	public Shape() {

	}

	public int menu() {
		num = sc.nextInt();
		return num;
	}

	public void circle() {
		int r;
		System.out.print("�������� �Է� : ");
		r = sc.nextInt();
		area = r * r * PI;
		output();

	}

	public void triangle() {
		int base;
		int high;

		System.out.print("��  �� : ");
		base = sc.nextInt();
		System.out.print("��  �� : ");
		high = sc.nextInt();
		area = base * high * (1 / 2.0);
		output();
	}

	public void trapezoid() {
		int lowerside;
		int upperside;
		int high;
		System.out.print("�Ʒ��� : ");
		lowerside = sc.nextInt();
		System.out.print("��  �� : ");
		upperside = sc.nextInt();
		System.out.print("��  �� : ");
		high = sc.nextInt();
		area = (lowerside + upperside) * high / 2;
		output();
	}

	public void output() {

		if (num == 1 || num == 3) {
			System.out.printf("���� : %.2f", area);
		} else if (num == 2) {
			System.out.print("���� : " + area);
		}

	}
}

public class Test37 {

	public static void main(String[] args) {

		Shape sp = new Shape();

		System.out.println("***��������*** 1.�� 2.�ﰢ�� 3.��ٸ��� 4.����");
		switch (sp.menu()) {
		case 1:
			sp.circle();
			break;

		case 2:
			sp.triangle();
			break;

		case 3:
			sp.trapezoid();
			break;
		case 4:
			System.out.println("�����մϴ�.^-^");
			System.exit(0);
		}

	}

}
